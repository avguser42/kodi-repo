import os
import shutil

import xbmc
import xbmcvfs

_LOG_TAG = '[WelcomeSetup]'


def install_skin_config(addon_path):
    src_root = os.path.join(addon_path, 'resources', 'skin')
    dst_root = xbmcvfs.translatePath('special://userdata/addon_data/')
    count = 0

    for dirpath, _dirs, files in os.walk(src_root):
        for filename in files:
            src = os.path.join(dirpath, filename)
            rel = os.path.relpath(src, src_root)
            dst = os.path.join(dst_root, rel)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(src, dst)
            xbmc.log(f'{_LOG_TAG} Installed skin file: {rel}', xbmc.LOGINFO)
            count += 1

    xbmc.log(f'{_LOG_TAG} Skin config installed ({count} files)', xbmc.LOGINFO)
