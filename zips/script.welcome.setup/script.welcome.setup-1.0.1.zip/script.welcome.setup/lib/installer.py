import gzip
import json
import os
import re
import time
import urllib.request
import xml.etree.ElementTree as ET
import zipfile

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

_LOG_TAG = '[WelcomeSetup]'
_KODI_VERSION = 21


def _ver_tuple(v):
    try:
        return tuple(int(x) for x in v.split('.'))
    except Exception:
        return (0,)


class Installer:
    def __init__(self, addon_path):
        self.resources = os.path.join(addon_path, 'resources')
        self.addons_dir = xbmcvfs.translatePath('special://home/addons/')
        self.progress = xbmcgui.DialogProgress()

    def run(self):
        repos = self._load('repos.json')
        addons = self._load('addons.json')
        settings = self._load('settings.json')

        xbmc.log(f'{_LOG_TAG} run: {len(repos)} repos, {len(addons)} addons, {len(settings)} settings', xbmc.LOGINFO)

        if not repos and not addons and not settings:
            xbmcgui.Dialog().ok('Setup', 'No items configured yet.')
            return

        total = len(repos) + len(addons) + len(settings)
        self.progress.create('Welcome Setup', 'Starting...')
        step = 0

        # Step 1: extract repo zips
        for repo in repos:
            if self.progress.iscanceled():
                self.progress.close()
                return
            if repo.get('index_only'):
                step += 1
                continue
            self.progress.update(self._pct(step, total), f"Installing repo: {repo.get('name', repo.get('id', ''))}")
            self._install_repo(repo)
            step += 1

        # Step 2: build download index from each repo's addons.xml
        self.progress.update(self._pct(step, total), 'Indexing repositories...')
        addon_index = self._build_addon_index(repos)

        # Step 3: download each addon directly (no Kodi installer needed)
        for addon_id in addons:
            if self.progress.iscanceled():
                self.progress.close()
                return
            self.progress.update(self._pct(step, total), f'Installing: {addon_id}')
            self._install_addon(addon_id, addon_index)
            step += 1

        # Step 4: apply settings
        for entry in settings:
            if self.progress.iscanceled():
                self.progress.close()
                return
            self.progress.update(self._pct(step, total), f"Applying setting: {entry.get('key', '')}")
            self._apply_setting(entry)
            step += 1

        self.progress.close()

    # --- helpers ---

    def _load(self, filename):
        path = os.path.join(self.resources, filename)
        if not xbmcvfs.exists(path):
            return []
        with xbmcvfs.File(path) as f:
            try:
                return json.loads(f.read())
            except Exception as e:
                xbmc.log(f'{_LOG_TAG} Failed to parse {filename}: {e}', xbmc.LOGERROR)
                return []

    @staticmethod
    def _pct(step, total):
        return int(step / total * 100) if total else 0

    def _install_repo(self, repo):
        addon_id = repo.get('id', 'unknown')
        source_url = repo.get('source_url', '').rstrip('/')
        if not source_url:
            return
        try:
            with urllib.request.urlopen(source_url + '/', timeout=10) as resp:
                content = resp.read().decode('utf-8', errors='replace')
            match = re.search(rf'{re.escape(addon_id)}-[\d.]+\.zip', content)
            if not match:
                xbmc.log(f'{_LOG_TAG} {addon_id} zip not found at {source_url}', xbmc.LOGERROR)
                return
            zip_url = f'{source_url}/{match.group(0)}'
            tmp = xbmcvfs.translatePath(f'special://temp/{addon_id}.zip')
            urllib.request.urlretrieve(zip_url, tmp)
            with zipfile.ZipFile(tmp, 'r') as zf:
                zf.extractall(self.addons_dir)
            xbmcvfs.delete(tmp)
            xbmc.log(f'{_LOG_TAG} Installed repo: {addon_id}', xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f'{_LOG_TAG} Failed repo {addon_id}: {e}', xbmc.LOGERROR)

    def _build_addon_index(self, repos):
        """Download addons.xml from each repo and build {addon_id: zip_url} index."""
        kodi = (_KODI_VERSION, 0, 0)
        index = {}

        for repo in repos:
            repo_id = repo.get('id', '')

            if repo.get('index_only'):
                addons_xml_url = repo.get('addons_xml_url', '')
                datadir = repo.get('datadir', '').rstrip('/')
                if not addons_xml_url or not datadir:
                    continue
                try:
                    addons_xml = self._fetch_addons_xml(addons_xml_url)
                    count = 0
                    for addon_elem in ET.fromstring(addons_xml).findall('addon'):
                        aid = addon_elem.get('id', '')
                        ver = addon_elem.get('version', '')
                        if aid and ver and aid not in index:
                            index[aid] = f'{datadir}/{aid}/{aid}-{ver}.zip'
                            count += 1
                    xbmc.log(f'{_LOG_TAG} Indexed {count} addons from {repo_id}', xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log(f'{_LOG_TAG} Failed to index {repo_id}: {e}', xbmc.LOGWARNING)
                continue

            addon_xml_path = os.path.join(self.addons_dir, repo_id, 'addon.xml')
            if not os.path.exists(addon_xml_path):
                xbmc.log(f'{_LOG_TAG} {repo_id}/addon.xml not found', xbmc.LOGWARNING)
                continue
            try:
                root = ET.parse(addon_xml_path).getroot()
                repo_ext = root.find('.//extension[@point="xbmc.addon.repository"]')
                if repo_ext is None:
                    continue
                for dir_elem in repo_ext.findall('dir'):
                    min_v = _ver_tuple(dir_elem.get('minversion', '0'))
                    max_v = _ver_tuple(dir_elem.get('maxversion', '999'))
                    if not (min_v <= kodi <= max_v):
                        continue
                    info_elem = dir_elem.find('info')
                    datadir_elem = dir_elem.find('datadir')
                    if info_elem is None or datadir_elem is None:
                        continue
                    info_url = info_elem.text.strip()
                    datadir = datadir_elem.text.strip().rstrip('/')
                    try:
                        with urllib.request.urlopen(info_url, timeout=15) as resp:
                            addons_xml = resp.read()
                        addons_root = ET.fromstring(addons_xml)
                        count = 0
                        for addon_elem in addons_root.findall('addon'):
                            aid = addon_elem.get('id', '')
                            ver = addon_elem.get('version', '')
                            if aid and ver and aid not in index:
                                index[aid] = f'{datadir}/{aid}/{aid}-{ver}.zip'
                                count += 1
                        xbmc.log(f'{_LOG_TAG} Indexed {count} addons from {repo_id}', xbmc.LOGINFO)
                    except Exception as e:
                        xbmc.log(f'{_LOG_TAG} Failed to fetch addons.xml from {repo_id}: {e}', xbmc.LOGWARNING)
            except Exception as e:
                xbmc.log(f'{_LOG_TAG} Failed to parse {repo_id}/addon.xml: {e}', xbmc.LOGERROR)

        xbmc.log(f'{_LOG_TAG} Total index: {len(index)} addons', xbmc.LOGINFO)
        return index

    def _fetch_addons_xml(self, addons_xml_url):
        """
        The official Kodi repo's addons.xml is ~12MB uncompressed but ~2MB gzipped
        (mirrors.kodi.tv serves both). Try the .gz first since it's much faster on
        a slow connection; fall back to the plain XML with a longer timeout.
        """
        try:
            with urllib.request.urlopen(addons_xml_url + '.gz', timeout=20) as resp:
                return gzip.decompress(resp.read())
        except Exception as e:
            xbmc.log(f'{_LOG_TAG} Falling back to uncompressed addons.xml: {e}', xbmc.LOGWARNING)
        with urllib.request.urlopen(addons_xml_url, timeout=90) as resp:
            return resp.read()

    def _install_addon(self, addon_id, addon_index):
        addon_path = os.path.join(self.addons_dir, addon_id, 'addon.xml')
        if os.path.exists(addon_path):
            xbmc.log(f'{_LOG_TAG} Already installed: {addon_id}', xbmc.LOGINFO)
            return
        zip_url = addon_index.get(addon_id)
        if not zip_url:
            xbmc.log(f'{_LOG_TAG} Not in any repo index: {addon_id}', xbmc.LOGERROR)
            return
        xbmc.log(f'{_LOG_TAG} Downloading {addon_id} from {zip_url}', xbmc.LOGINFO)
        try:
            tmp = xbmcvfs.translatePath(f'special://temp/{addon_id}.zip')
            urllib.request.urlretrieve(zip_url, tmp)
            with zipfile.ZipFile(tmp, 'r') as zf:
                zf.extractall(self.addons_dir)
            xbmcvfs.delete(tmp)
            xbmc.log(f'{_LOG_TAG} Installed: {addon_id}', xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f'{_LOG_TAG} Failed to install {addon_id}: {e}', xbmc.LOGERROR)

    def _apply_setting(self, entry):
        try:
            addon_id = entry.get('addon_id')
            key = entry.get('key', '')
            value = str(entry.get('value', ''))
            if addon_id:
                xbmcaddon.Addon(addon_id).setSetting(key, value)
            else:
                xbmc.executeJSONRPC(json.dumps({
                    'jsonrpc': '2.0',
                    'method': 'Settings.SetSettingValue',
                    'params': {'setting': key, 'value': entry.get('value')},
                    'id': 1,
                }))
            xbmc.log(f'{_LOG_TAG} Applied setting {key}={value}', xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f'{_LOG_TAG} Failed setting {entry}: {e}', xbmc.LOGERROR)
