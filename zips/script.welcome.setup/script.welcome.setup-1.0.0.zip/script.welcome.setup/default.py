import sys

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon('script.welcome.setup')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
FLAG_FILE = xbmcvfs.translatePath('special://userdata/.welcome_setup_done')

sys.path.insert(0, ADDON_PATH)

from lib.installer import Installer
from lib.skin import install_skin_config
from lib import auth


class WelcomeService(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self._run()

    def _run(self):
        xbmc.sleep(3000)  # wait for Kodi UI to be ready

        if xbmcvfs.exists(FLAG_FILE):
            return

        dialog = xbmcgui.Dialog()

        if not dialog.yesno(
            'Welcome',
            'Run first-time setup?\n\nThis will install repositories, addons, and configure the skin.',
            yeslabel="Let's Go",
            nolabel='Skip',
        ):
            return

        # Phase 1: install repos and addons
        xbmc.log('[WelcomeSetup] Phase 1: starting installer', xbmc.LOGINFO)
        Installer(ADDON_PATH).run()
        xbmc.log('[WelcomeSetup] Phase 1: installer done', xbmc.LOGINFO)

        # Refresh Kodi's in-memory addon registry so newly installed addons are usable
        xbmc.log('[WelcomeSetup] Calling UpdateLocalAddons()', xbmc.LOGINFO)
        xbmc.executebuiltin('UpdateLocalAddons()')
        xbmc.sleep(3000)
        xbmc.log('[WelcomeSetup] UpdateLocalAddons() sleep done', xbmc.LOGINFO)

        # Enable every installed addon in the DB so Kodi can invoke them
        # (UpdateLocalAddons registers addons on disk but leaves them disabled by default)
        import json as _json
        import os as _os
        _addons_json = _os.path.join(ADDON_PATH, 'resources', 'addons.json')
        try:
            with open(_addons_json) as _f:
                _addon_ids = _json.load(_f)
            for _aid in _addon_ids:
                xbmc.executeJSONRPC(_json.dumps({
                    'jsonrpc': '2.0', 'id': 1,
                    'method': 'Addons.SetAddonEnabled',
                    'params': {'addonid': _aid, 'enabled': True},
                }))
            xbmc.log(f'[WelcomeSetup] Enabled {len(_addon_ids)} addons in DB', xbmc.LOGINFO)
        except Exception as _e:
            xbmc.log(f'[WelcomeSetup] Failed to enable addons: {_e}', xbmc.LOGWARNING)

        # Phase 2: apply skin layout and widget config
        xbmc.log('[WelcomeSetup] Phase 2: applying skin config', xbmc.LOGINFO)
        install_skin_config(ADDON_PATH)
        xbmc.log('[WelcomeSetup] Phase 2: skin config done', xbmc.LOGINFO)

        # Phase 3: streaming account setup (each skippable)
        xbmc.log('[WelcomeSetup] Phase 3: starting account setup', xbmc.LOGINFO)
        self._setup_accounts(dialog)
        xbmc.log('[WelcomeSetup] Phase 3: account setup done', xbmc.LOGINFO)

        with xbmcvfs.File(FLAG_FILE, 'w') as f:
            f.write('done')

        # Phase 4: instruct user to restart before doing anything else.
        # Newly-installed addons (POV included) get a broken language-string
        # object if used in the same session they were installed in - only a
        # full restart fixes that. Mid-session skin switches separately trigger
        # a skinvariables reload cascade that crashes Kodi. Restarting first
        # covers both.
        dialog.ok(
            'Setup Complete',
            'Setup is complete!\n\n'
            'IMPORTANT: Restart Kodi now before using any addon '
            '(including POV) - newly installed addons need a fresh '
            'restart to work correctly.\n\n'
            'Then activate the skin:\n'
            '1. Settings → Interface → Skin → Arctic Fuse 3\n'
            '2. Restart Kodi again',
        )

    def _setup_accounts(self, dialog):
        if not dialog.yesno(
            'Streaming Accounts',
            'Set up your streaming accounts?\n\nYou can skip any service and configure it later in POV settings.',
            yeslabel='Set Up',
            nolabel='Skip All',
        ):
            return

        services = [
            ('Real-Debrid', auth.auth_realdebrid),
            ('Torbox', auth.auth_torbox),
            ('Trakt', auth.auth_trakt),
            ('TMDB', auth.auth_tmdb),
        ]

        for name, fn in services:
            if dialog.yesno(
                name,
                f'Set up {name}?',
                yeslabel='Set Up',
                nolabel='Skip',
            ):
                fn()


if __name__ == '__main__':
    WelcomeService()
