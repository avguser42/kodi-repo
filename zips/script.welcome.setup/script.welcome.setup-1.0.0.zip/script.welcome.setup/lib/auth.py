import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from threading import Thread

import xbmc
import xbmcgui
import xbmcvfs

_LOG_TAG = '[WelcomeSetup]'
_RD_APP_CLIENT_ID = 'X245A4XAIBGVM'
_RD_BASE = 'https://app.real-debrid.com/oauth/v2'
_TB_BASE = 'https://api.torbox.app/v1/api'
_QR_URL = 'https://api.qrserver.com/v1/create-qr-code/?size=256x256&qzone=1&data=%s'


def _get(url, headers=None):
    h = {'User-Agent': 'python-requests/2.28.2', 'Accept': '*/*'}
    h.update(headers or {})
    req = urllib.request.Request(url, headers=h)
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read())


def _post(url, data, headers=None):
    """POST as JSON (used by Trakt, Torbox)."""
    body = json.dumps(data).encode()
    h = {'Content-Type': 'application/json', 'User-Agent': 'python-requests/2.28.2', 'Accept': '*/*'}
    h.update(headers or {})
    req = urllib.request.Request(url, data=body, headers=h)
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read())


def _post_form(url, data, headers=None):
    """POST as form-encoded (required by RealDebrid token endpoint)."""
    body = urllib.parse.urlencode(data).encode()
    h = {'Content-Type': 'application/x-www-form-urlencoded'}
    h.update(headers or {})
    req = urllib.request.Request(url, data=body, headers=h)
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read())


class _AuthDialog(xbmcgui.WindowXMLDialog):
    """Full-screen auth dialog with QR code, countdown, and progress bar."""

    _BACK = (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_STOP)

    def __init__(self, *args, **kwargs):
        # Kodi's C++ WindowXMLDialog constructor expects the positional args as a tuple.
        # Calling super().__init__(xml, path, ...) separately causes Kodi to misread them.
        super().__init__(args)
        self.cancelled = False
        self._title = kwargs.get('title', '')
        self._url = kwargs.get('url', '')
        self._code = kwargs.get('code', '')
        self._qr_url = kwargs.get('qr_url', '')

    def onInit(self):
        try:
            self.getControl(101).setLabel(f'[B]{self._title}[/B]')
        except Exception:
            pass
        if self._qr_url:
            try:
                self.getControl(100).setImage(self._qr_url)
            except Exception:
                pass

    def update(self, text, progress):
        try:
            self.getControl(200).setText(text)
            self.getControl(300).setPercent(float(progress))
        except Exception:
            pass

    def iscanceled(self):
        return self.cancelled

    def onAction(self, action):
        if action.getId() in self._BACK:
            self.cancelled = True
            self.close()

    def run(self):
        self.doModal()


def _wait_for_auth(title, url, code, check_fn, interval, timeout):
    """
    Show auth dialog (QR + countdown) and poll check_fn every interval seconds.
    Updates dialog every second with remaining time. Returns result or False.
    """
    try:
        qr_url = _QR_URL % urllib.parse.quote(url, safe='')
    except Exception:
        qr_url = ''

    addon_path = xbmcvfs.translatePath('special://home/addons/script.welcome.setup/')
    window = _AuthDialog('auth_dialog.xml', addon_path, title=title, url=url, code=code, qr_url=qr_url)
    thread = Thread(target=window.run, daemon=True)
    thread.start()

    expires_at = time.monotonic() + timeout
    elapsed = 0
    result = None

    while not window.cancelled and time.monotonic() < expires_at:
        xbmc.sleep(1000)
        elapsed += 1
        remaining = max(0, expires_at - time.monotonic())
        mins, secs = divmod(int(remaining), 60)
        window.update(
            f'REMAINING: [B]{mins:02d}:{secs:02d}[/B][CR]'
            f'LOCATION: [B]{url}[/B][CR]'
            f'PIN CODE: [B]{code}[/B]',
            int(100 * remaining / timeout),
        )
        if elapsed % interval == 0:
            try:
                result = check_fn()
            except Exception as e:
                xbmc.log(f'{_LOG_TAG} Poll error ({title}): {e}', xbmc.LOGWARNING)
            if result is not None:
                break

    window.close()
    thread.join(timeout=2)
    xbmc.sleep(800)  # let the full-screen dialog fully dismiss before next UI appears
    return False if (window.cancelled or result is None) else result


def _write_pov_setting(key, value):
    """Write directly to POV's settings.xml, bypassing the addon registry."""
    addon_data = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.pov/')
    os.makedirs(addon_data, exist_ok=True)
    settings_path = os.path.join(addon_data, 'settings.xml')

    if os.path.exists(settings_path):
        try:
            tree = ET.parse(settings_path)
            root = tree.getroot()
        except ET.ParseError:
            root = ET.Element('settings', attrib={'version': '2'})
            tree = ET.ElementTree(root)
    else:
        root = ET.Element('settings', attrib={'version': '2'})
        tree = ET.ElementTree(root)

    setting = next((s for s in root.findall('setting') if s.get('id') == key), None)
    if setting is None:
        setting = ET.SubElement(root, 'setting', id=key)
    setting.text = str(value)
    tree.write(settings_path, encoding='unicode', xml_declaration=False)


def _read_pov_default(key):
    """Read a default setting value from POV's bundled resources/settings.xml."""
    pov_dir = xbmcvfs.translatePath('special://home/addons/plugin.video.pov/')
    settings_path = os.path.join(pov_dir, 'resources', 'settings.xml')
    if not os.path.exists(settings_path):
        xbmc.log(f'{_LOG_TAG} POV resources/settings.xml not found', xbmc.LOGERROR)
        return ''
    try:
        tree = ET.parse(settings_path)
        root = tree.getroot()
        for elem in root.iter('setting'):
            if elem.get('id') == key:
                default_elem = elem.find('default')
                if default_elem is not None:
                    return default_elem.text or ''
                return elem.get('default', '')
    except Exception as e:
        xbmc.log(f'{_LOG_TAG} Failed to read POV default {key}: {e}', xbmc.LOGERROR)
    return ''


def auth_tmdb():
    """
    TMDB has no device-code flow for minting a new API key, so the user has to
    create one manually on themoviedb.org and paste it in. Without this, POV's
    own list/metadata calls (tmdb_api.py) 401 on everything since POV (unlike
    TMDbHelper) doesn't bundle a shared key.
    """
    dialog = xbmcgui.Dialog()

    dialog.ok(
        'TMDB',
        'POV needs a free TMDB API key to load movie/show info and build lists.\n\n'
        '1. Go to themoviedb.org and create a free account\n'
        '2. Settings -> API -> Create -> request an API key\n'
        '3. Copy the "API Read Access Token" (the long one)\n\n'
        'Tip: this token is long and painful to type with a remote. '
        'If typing on this device is hard (e.g. Android TV), install '
        'the "Kore" remote app on your phone (or use your TV\'s '
        'phone-keyboard casting) - it lets you type into this box '
        'using your phone\'s keyboard.',
    )

    token = dialog.input('Paste your TMDB API Read Access Token')
    if not token:
        return False

    try:
        resp = _get(
            'https://api.themoviedb.org/3/authentication',
            headers={'Authorization': f'Bearer {token.strip()}'},
        )
    except Exception as e:
        xbmc.log(f'{_LOG_TAG} TMDB token validation error: {e}', xbmc.LOGERROR)
        dialog.ok('TMDB', 'Could not validate that token. Set it up later in POV settings.')
        return False

    if not resp.get('success'):
        dialog.ok('TMDB', 'That token was rejected by TMDB. Set it up later in POV settings.')
        return False

    _write_pov_setting('tmdb_read_token', token.strip())
    xbmc.log(f'{_LOG_TAG} TMDB authorized', xbmc.LOGINFO)
    dialog.notification('TMDB', 'API key saved!', xbmcgui.NOTIFICATION_INFO)
    return True


def auth_realdebrid():
    dialog = xbmcgui.Dialog()
    try:
        resp = _get(f'{_RD_BASE}/device/code?client_id={_RD_APP_CLIENT_ID}&new_credentials=yes')
    except Exception as e:
        xbmc.log(f'{_LOG_TAG} RD device code error: {e}', xbmc.LOGERROR)
        dialog.ok('Real-Debrid', 'Could not connect to Real-Debrid. Check your connection.')
        return False

    device_code = resp['device_code']
    user_code = resp['user_code']
    verification_url = resp.get('direct_verification_url') or resp['verification_url']
    poll_url = resp['verification_url']
    interval = resp.get('interval', 5)
    expires_in = resp.get('expires_in', 1800)

    credentials = {}

    def _check():
        try:
            data = _get(f'{_RD_BASE}/device/credentials?client_id={_RD_APP_CLIENT_ID}&code={device_code}')
            credentials.update(data)
            return credentials
        except Exception:
            return None

    if not _wait_for_auth('Real-Debrid', verification_url, user_code, _check, interval, expires_in):
        return False

    try:
        token_resp = _post_form(f'{_RD_BASE}/token', {
            'client_id': credentials['client_id'],
            'client_secret': credentials['client_secret'],
            'code': device_code,
            'grant_type': 'http://oauth.net/grant_type/device/1.0',
        })
        user_resp = _get(
            'https://app.real-debrid.com/rest/1.0/user',
            headers={'Authorization': f"Bearer {token_resp['access_token']}"},
        )
        _write_pov_setting('rd.client_id', credentials['client_id'])
        _write_pov_setting('rd.secret', credentials['client_secret'])
        _write_pov_setting('rd.token', token_resp['access_token'])
        _write_pov_setting('rd.refresh', token_resp['refresh_token'])
        _write_pov_setting('rd.username', user_resp.get('username', ''))
        _write_pov_setting('rd.enabled', 'true')
        xbmc.log(f'{_LOG_TAG} RealDebrid authorized', xbmc.LOGINFO)
        dialog.notification('Real-Debrid', 'Authorization successful!', xbmcgui.NOTIFICATION_INFO)
        return True
    except Exception as e:
        xbmc.log(f'{_LOG_TAG} RD token exchange error: {e}', xbmc.LOGERROR)
        dialog.ok('Real-Debrid', 'Authorization failed. Set it up later in POV settings.')
        return False


def auth_torbox():
    dialog = xbmcgui.Dialog()
    try:
        resp = _get(f'{_TB_BASE}/user/auth/device/start',
                     headers={'User-Agent': 'POV/1.0'})
        data = resp['data']
    except Exception as e:
        xbmc.log(f'{_LOG_TAG} Torbox device start error: {e}', xbmc.LOGERROR)
        dialog.ok('Torbox', 'Could not connect to Torbox. Check your connection.')
        return False

    device_code = data['device_code']
    user_code = data['code']
    verification_url = data.get('friendly_verification_url') or data.get('verification_url', 'torbox.app')
    interval = data.get('interval', 5)

    token_data = {}

    def _check():
        try:
            r = _post(f'{_TB_BASE}/user/auth/device/token', {'device_code': device_code})
            if r.get('data', {}).get('access_token'):
                token_data.update(r['data'])
                return token_data
            return None
        except Exception:
            return None

    if not _wait_for_auth('Torbox', verification_url, user_code, _check, interval, 600):
        return False

    try:
        access_token = token_data['access_token']
        user_resp = _get(f'{_TB_BASE}/user/me',
                          headers={'Authorization': f'Bearer {access_token}'})
        customer = user_resp.get('data', {}).get('customer', '')
        _write_pov_setting('tb.token', access_token)
        _write_pov_setting('tb.account_id', str(customer))
        _write_pov_setting('tb.enabled', 'true')
        xbmc.log(f'{_LOG_TAG} Torbox authorized', xbmc.LOGINFO)
        dialog.notification('Torbox', 'Authorization successful!', xbmcgui.NOTIFICATION_INFO)
        return True
    except Exception as e:
        xbmc.log(f'{_LOG_TAG} Torbox token error: {e}', xbmc.LOGERROR)
        dialog.ok('Torbox', 'Authorization failed. Set it up later in POV settings.')
        return False


def auth_trakt():
    dialog = xbmcgui.Dialog()
    client_id = _read_pov_default('trakt.client_id')
    client_secret = _read_pov_default('trakt.client_secret')

    if not client_id or not client_secret:
        xbmc.log(f'{_LOG_TAG} Trakt credentials not found in POV resources', xbmc.LOGERROR)
        dialog.ok('Trakt', 'Could not read Trakt credentials from POV.\nSet up Trakt later in POV settings.')
        return False

    _TRAKT_BASE = 'https://api.trakt.tv'

    try:
        resp = _post(f'{_TRAKT_BASE}/oauth/device/code',
                     {'client_id': client_id, 'client_secret': client_secret, 'code': ''})
    except Exception as e:
        xbmc.log(f'{_LOG_TAG} Trakt device code error: {e}', xbmc.LOGERROR)
        dialog.ok('Trakt', 'Could not connect to Trakt. Check your connection.')
        return False

    device_code = resp['device_code']
    user_code = resp['user_code']
    verification_url = resp['verification_url']
    interval = resp.get('interval', 5)
    expires_in = resp.get('expires_in', 600)

    token_resp = {}

    def _check():
        try:
            r = _post(f'{_TRAKT_BASE}/oauth/device/token',
                      {'client_id': client_id, 'client_secret': client_secret, 'code': device_code})
            if r.get('access_token'):
                token_resp.update(r)
                return token_resp
            return None
        except Exception:
            return None

    if not _wait_for_auth('Trakt', verification_url, user_code, _check, interval, expires_in):
        return False

    try:
        access_token = token_resp['access_token']
        _api_h = {'trakt-api-key': client_id, 'trakt-api-version': '2', 'Authorization': f'Bearer {access_token}'}
        user_resp = _get(f'{_TRAKT_BASE}/users/me', headers=_api_h)
        expires = int(token_resp['created_at']) + int(token_resp['expires_in'])
        _write_pov_setting('trakt.token', access_token)
        _write_pov_setting('trakt.refresh', token_resp['refresh_token'])
        _write_pov_setting('trakt.expires', str(expires))
        _write_pov_setting('trakt_user', user_resp.get('username', ''))
        _write_pov_setting('trakt_indicators_active', 'true')
        _write_pov_setting('watched_indicators', '1')
        xbmc.log(f'{_LOG_TAG} Trakt authorized', xbmc.LOGINFO)
        dialog.notification('Trakt', 'Authorization successful!', xbmcgui.NOTIFICATION_INFO)
        return True
    except Exception as e:
        xbmc.log(f'{_LOG_TAG} Trakt token error: {e}', xbmc.LOGERROR)
        dialog.ok('Trakt', 'Authorization failed. Set it up later in POV settings.')
        return False
