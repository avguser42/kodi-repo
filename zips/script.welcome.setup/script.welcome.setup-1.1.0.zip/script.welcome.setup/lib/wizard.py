import hashlib
import json
import os

import xbmc
import xbmcgui
import xbmcvfs

from lib import auth
from lib.installer import Installer
from lib.skin import install_skin_config

_LOG_TAG = '[WelcomeSetup]'
FLAG_FILE = xbmcvfs.translatePath('special://userdata/.welcome_setup_done')
CONFIG_HASH_FILE = xbmcvfs.translatePath('special://userdata/.welcome_setup_config_hash')
_TARGET_SKIN = 'skin.arctic.fuse.3'
_CONFIG_FILES = ('repos.json', 'addons.json', 'settings.json')


def _rebuild_skin_shortcuts():
    """
    script.skinvariables compiles our shortcut JSON (search widgets, home menu, etc.)
    into real skin XML asynchronously. On a skin's first activation this can lose the
    race against the skin's own initial parse, leaving menus like Search silently
    empty (only the built-in "Discover" tile) even though the JSON is fine and gets
    compiled moments later. Forcing a rebuild + reload fixes that - but ONLY when the
    target skin is already active and settled. Do NOT use this to switch *into* the
    skin: switching skins programmatically during early login triggers the skin's own
    reload cascade mid-startup and hard-crashes Kodi (verified). The user switches to
    the skin manually from Settings, which is safe; this just tidies up afterward if
    the wizard happens to run while already on it (e.g. a manual re-run).
    """
    if xbmc.getSkinDir() != _TARGET_SKIN:
        return
    xbmc.log(f'{_LOG_TAG} Forcing skinvariables template rebuild + skin reload', xbmc.LOGINFO)
    xbmc.executebuiltin('RunScript(script.skinvariables,action=buildtemplate,force)')
    xbmc.sleep(2000)
    xbmc.executebuiltin('ReloadSkin()')


def _enable_configured_addons(addon_path):
    """UpdateLocalAddons() registers newly-extracted addons on disk but leaves them
    disabled in Kodi's DB by default - flip them on so Kodi will actually invoke them."""
    addons_json = os.path.join(addon_path, 'resources', 'addons.json')
    try:
        with open(addons_json) as f:
            addon_ids = json.load(f)
        for aid in addon_ids:
            xbmc.executeJSONRPC(json.dumps({
                'jsonrpc': '2.0', 'id': 1,
                'method': 'Addons.SetAddonEnabled',
                'params': {'addonid': aid, 'enabled': True},
            }))
        xbmc.log(f'{_LOG_TAG} Enabled {len(addon_ids)} addons in DB', xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f'{_LOG_TAG} Failed to enable addons: {e}', xbmc.LOGWARNING)


def _config_hash(addon_path):
    resources = os.path.join(addon_path, 'resources')
    parts = []
    for filename in _CONFIG_FILES:
        path = os.path.join(resources, filename)
        if os.path.exists(path):
            with open(path, 'rb') as f:
                parts.append(f.read())
    return hashlib.sha256(b'\x00'.join(parts)).hexdigest()


def _write_config_hash(addon_path):
    with xbmcvfs.File(CONFIG_HASH_FILE, 'w') as f:
        f.write(_config_hash(addon_path))


def top_up_if_config_changed(addon_path):
    """
    Runs on every login once initial setup is done. FLAG_FILE permanently blocks
    the auto-service from running again, so without this, a future addon update
    that adds a new repo/addon/setting would never reach anyone who already
    finished setup - only brand-new installs would get it. Silently installs just
    what's new (skip_existing=True, no dialogs); a notification only appears if
    something actually got installed.
    """
    if not xbmcvfs.exists(FLAG_FILE):
        return  # initial setup hasn't happened yet - the normal flow handles this

    current_hash = _config_hash(addon_path)
    stored_hash = ''
    if xbmcvfs.exists(CONFIG_HASH_FILE):
        with xbmcvfs.File(CONFIG_HASH_FILE) as f:
            stored_hash = f.read().strip()

    if stored_hash == current_hash:
        return

    xbmc.log(f'{_LOG_TAG} Wizard config changed since last check, looking for new items', xbmc.LOGINFO)
    stats = Installer(addon_path, skip_existing=True).run() or {}

    xbmc.executebuiltin('UpdateLocalAddons()')
    xbmc.sleep(3000)
    _enable_configured_addons(addon_path)

    install_skin_config(addon_path)
    _rebuild_skin_shortcuts()

    _write_config_hash(addon_path)

    total_new = stats.get('repos_installed', 0) + stats.get('addons_installed', 0)
    if total_new:
        xbmc.log(f'{_LOG_TAG} Top-up installed {total_new} new item(s)', xbmc.LOGINFO)
        xbmcgui.Dialog().notification(
            'Welcome Setup',
            f'Installed {total_new} new item(s) - restart Kodi to use them.',
            xbmcgui.NOTIFICATION_INFO,
            8000,
        )


def run_wizard(addon_path, manual=False):
    dialog = xbmcgui.Dialog()

    if manual:
        if not dialog.yesno(
            'Setup Wizard',
            'Run the setup wizard now?\n\nThis (re)installs repositories, addons, and '
            'skin config, and lets you (re)connect your streaming accounts.',
            yeslabel='Run',
            nolabel='Cancel',
        ):
            return
        skip_existing = dialog.yesno(
            'Setup Wizard',
            'Skip anything that is already installed or already connected?',
            yeslabel='Skip Existing',
            nolabel='Redo Everything',
        )
    else:
        if xbmcvfs.exists(FLAG_FILE):
            return
        if not dialog.yesno(
            'Welcome',
            'Run first-time setup?\n\nThis will install repositories, addons, and configure the skin.',
            yeslabel="Let's Go",
            nolabel='Skip',
        ):
            return
        skip_existing = True

    # Phase 1: install repos and addons
    xbmc.log(f'{_LOG_TAG} Phase 1: starting installer', xbmc.LOGINFO)
    install_stats = Installer(addon_path, skip_existing=skip_existing).run() or {}
    xbmc.log(f'{_LOG_TAG} Phase 1: installer done', xbmc.LOGINFO)

    # Refresh Kodi's in-memory addon registry so newly installed addons are usable
    xbmc.log(f'{_LOG_TAG} Calling UpdateLocalAddons()', xbmc.LOGINFO)
    xbmc.executebuiltin('UpdateLocalAddons()')
    xbmc.sleep(3000)
    xbmc.log(f'{_LOG_TAG} UpdateLocalAddons() sleep done', xbmc.LOGINFO)

    _enable_configured_addons(addon_path)

    # Phase 2: apply skin layout and widget config
    xbmc.log(f'{_LOG_TAG} Phase 2: applying skin config', xbmc.LOGINFO)
    install_skin_config(addon_path)
    _rebuild_skin_shortcuts()
    xbmc.log(f'{_LOG_TAG} Phase 2: skin config done', xbmc.LOGINFO)

    # Phase 3: streaming account setup (each skippable)
    xbmc.log(f'{_LOG_TAG} Phase 3: starting account setup', xbmc.LOGINFO)
    account_results = _setup_accounts(dialog, skip_existing)
    xbmc.log(f'{_LOG_TAG} Phase 3: account setup done', xbmc.LOGINFO)

    # POV auto-updates via the repo; catch early if a future version renamed/dropped
    # a settings key we depend on, instead of failing silently.
    missing_settings = auth.check_pov_settings_compat()
    if missing_settings:
        xbmc.log(f'{_LOG_TAG} POV settings compat check: missing {missing_settings}', xbmc.LOGWARNING)

    if not manual:
        with xbmcvfs.File(FLAG_FILE, 'w') as f:
            f.write('done')
    _write_config_hash(addon_path)

    _show_summary(dialog, install_stats, account_results, missing_settings, manual)


def _show_summary(dialog, install_stats, account_results, missing_settings, manual):
    lines = ['Setup is complete!', '']
    lines.append(
        f"Installed: {install_stats.get('repos_installed', 0)} repos, "
        f"{install_stats.get('addons_installed', 0)} addons"
    )
    failed = install_stats.get('failed') or []
    if failed:
        shown = ', '.join(failed[:5]) + (', ...' if len(failed) > 5 else '')
        lines.append(f'⚠ Failed to install: {shown}')

    if account_results:
        outcome_labels = {
            'connected': 'connected',
            'already set': 'already set',
            'skipped': 'skipped',
            'failed': 'failed',
        }
        parts = [f'{name}: {outcome_labels.get(outcome, outcome)}' for name, outcome in account_results.items()]
        lines.append('Accounts – ' + ' | '.join(parts))

    if missing_settings:
        lines.append('')
        lines.append(
            '⚠ POV may have changed its settings format - some saved values '
            'might not apply. Check POV settings if something looks off.'
        )

    # Newly-installed addons (POV included) get a broken language-string object if
    # used in the same session they were installed in - only a full restart fixes
    # that. A manual re-run that only skipped/reconnected already-installed things
    # doesn't need this at all, so only show it when something was actually (re)installed.
    newly_installed = install_stats.get('repos_installed', 0) + install_stats.get('addons_installed', 0)
    if not manual:
        lines.append('')
        lines.append(
            'IMPORTANT: Restart Kodi now before using any addon (including POV) - '
            'newly installed addons need a fresh restart to work correctly.\n\n'
            'Then switch to the skin:\n'
            'Settings -> Interface -> Skin -> Arctic Fuse 3'
        )
    elif newly_installed:
        lines.append('')
        lines.append(
            'IMPORTANT: Restart Kodi now - newly installed addons need a fresh '
            'restart to work correctly.'
        )

    dialog.ok('Setup Complete', '\n'.join(lines))


def _setup_accounts(dialog, skip_existing):
    # is_valid_X() (not just is_authorized_X()) so a revoked/expired token gets
    # re-prompted here instead of silently skipped forever.
    services = [
        ('Real-Debrid', auth.auth_realdebrid, auth.is_valid_realdebrid),
        ('Torbox', auth.auth_torbox, auth.is_valid_torbox),
        ('Trakt', auth.auth_trakt, auth.is_valid_trakt),
    ]

    if not dialog.yesno(
        'Streaming Accounts',
        'Set up your streaming accounts?\n\nYou can skip any service and configure it later in POV settings.',
        yeslabel='Set Up',
        nolabel='Skip All',
    ):
        return {name: 'skipped' for name, _fn, _is_authed in services} | {'TMDB': 'skipped'}

    results = {}
    for name, fn, is_authed in services:
        if skip_existing and is_authed():
            xbmc.log(f'{_LOG_TAG} {name} already configured, skipping', xbmc.LOGINFO)
            results[name] = 'already set'
            continue
        if dialog.yesno(
            name,
            f'Set up {name}?',
            yeslabel='Set Up',
            nolabel='Skip',
        ):
            results[name] = 'connected' if fn() else 'failed'
        else:
            results[name] = 'skipped'

    # TMDB uses a built-in shared key by default, so it needs no user interaction
    # unless that key is unavailable - only auth_tmdb() itself prompts, and only then.
    if skip_existing and auth.is_authorized_tmdb():
        results['TMDB'] = 'already set'
    else:
        results['TMDB'] = 'connected' if auth.auth_tmdb() else 'failed'

    return results


def run_diagnostics(addon_path):
    """
    Self-service health check, reachable from Program Add-ons. Reports addon
    install/enabled state, active skin, live account validity, and the POV
    settings compatibility check - the same things that otherwise require reading
    the Kodi log by hand to figure out.
    """
    progress = xbmcgui.DialogProgress()
    progress.create('Welcome Setup', 'Running diagnostics...')
    lines = []

    progress.update(10, 'Checking addons...')
    addons_json = os.path.join(addon_path, 'resources', 'addons.json')
    try:
        with open(addons_json) as f:
            addon_ids = json.load(f)
    except Exception:
        addon_ids = []

    addons_dir = xbmcvfs.translatePath('special://home/addons/')
    missing, disabled = [], []
    for aid in addon_ids:
        if not os.path.exists(os.path.join(addons_dir, aid, 'addon.xml')):
            missing.append(aid)
            continue
        try:
            resp = json.loads(xbmc.executeJSONRPC(json.dumps({
                'jsonrpc': '2.0', 'id': 1,
                'method': 'Addons.GetAddonDetails',
                'params': {'addonid': aid, 'properties': ['enabled']},
            })))
            if not resp.get('result', {}).get('addon', {}).get('enabled', False):
                disabled.append(aid)
        except Exception as e:
            xbmc.log(f'{_LOG_TAG} Diagnostics: failed to check {aid}: {e}', xbmc.LOGWARNING)

    if missing:
        lines.append(f'✗ Missing addons ({len(missing)}): {", ".join(missing)}')
    if disabled:
        lines.append(f'⚠ Disabled addons ({len(disabled)}): {", ".join(disabled)}')
    if not missing and not disabled and addon_ids:
        lines.append(f'✓ All {len(addon_ids)} configured addons installed and enabled')

    progress.update(30, 'Checking skin...')
    active_skin = xbmc.getSkinDir()
    if active_skin == _TARGET_SKIN:
        lines.append(f'✓ Skin: {_TARGET_SKIN} is active')
    else:
        lines.append(f'⚠ Skin: {active_skin} is active (expected {_TARGET_SKIN})')

    progress.update(45, 'Checking Real-Debrid...')
    lines.append(_diagnostic_account_line('Real-Debrid', auth.is_authorized_realdebrid, auth.is_valid_realdebrid))
    progress.update(60, 'Checking Torbox...')
    lines.append(_diagnostic_account_line('Torbox', auth.is_authorized_torbox, auth.is_valid_torbox))
    progress.update(75, 'Checking Trakt...')
    lines.append(_diagnostic_account_line('Trakt', auth.is_authorized_trakt, auth.is_valid_trakt))
    progress.update(90, 'Checking TMDB...')
    lines.append(_diagnostic_account_line('TMDB', auth.is_authorized_tmdb, auth.is_valid_tmdb))

    progress.update(97, 'Checking POV settings compatibility...')
    missing_settings = auth.check_pov_settings_compat()
    if missing_settings:
        lines.append(f'⚠ POV settings no longer recognised: {", ".join(missing_settings)}')
    else:
        lines.append('✓ POV settings schema matches what this wizard expects')

    progress.close()
    xbmcgui.Dialog().textviewer('Welcome Setup Diagnostics', '\n'.join(lines))


def _diagnostic_account_line(name, is_authed, is_valid):
    if not is_authed():
        return f'– {name}: not configured'
    if is_valid():
        return f'✓ {name}: connected and working'
    return f'✗ {name}: saved but no longer valid - reconnect via Program Add-ons'


def reset_wizard_state():
    """
    Clears the wizard's own state flags so the first-run flow triggers fresh on the
    next launch. Only touches our own marker files - installed addons, skin config,
    and connected accounts are left intact (a fresh first-run with 'skip existing'
    won't disturb them). Mainly for testing and for users who want a clean do-over
    without hand-deleting dotfiles from userdata.
    """
    dialog = xbmcgui.Dialog()
    if not dialog.yesno(
        'Reset Setup State',
        'This makes the first-run setup wizard appear again on next launch.\n\n'
        'Your installed addons, skin, and connected accounts are NOT removed. '
        'Continue?',
        yeslabel='Reset',
        nolabel='Cancel',
    ):
        return

    removed = 0
    for flag in (FLAG_FILE, CONFIG_HASH_FILE):
        if xbmcvfs.exists(flag):
            try:
                xbmcvfs.delete(flag)
                removed += 1
            except Exception as e:
                xbmc.log(f'{_LOG_TAG} Failed to delete {flag}: {e}', xbmc.LOGWARNING)

    xbmc.log(f'{_LOG_TAG} Reset wizard state ({removed} flag file(s) cleared)', xbmc.LOGINFO)
    dialog.ok(
        'Reset Setup State',
        'Done. The setup wizard will run again next time you start Kodi '
        '(or you can run it now from this menu).',
    )
