import base64
import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from threading import Thread

import xbmc
import xbmcgui
import xbmcvfs

_LOG_TAG = '[WelcomeSetup]'
_RD_APP_CLIENT_ID = 'X245A4XAIBGVM'
_RD_BASE = 'https://app.real-debrid.com/oauth/v2'
_TB_BASE = 'https://api.torbox.app/v1/api'
_QR_URL = 'https://api.qrserver.com/v1/create-qr-code/?size=256x256&qzone=1&data=%s'
# Marker: present only while the saved TMDB token is the build's shared one (not a
# user's own pasted key). Lets heal_tmdb_token_if_rotated() run on the login path
# without ever touching the network for the common case or for custom-key users.
_TMDB_SHARED_FLAG = xbmcvfs.translatePath('special://userdata/.welcome_setup_tmdb_shared')

# Dedicated TMDB Read Access Token for this build, shared across every install so
# nobody has to generate/paste their own. TMDB staff have confirmed a single key
# shared across all of an app's users is fine (the actual rule is just not exposing
# it in a public repo/searchable source) - split/base64'd here purely to dodge casual
# grep/bot scraping, not as real security. If TMDB ever flags and revokes it, generate
# a fresh one and bump the addon version; existing installs are unaffected since their
# token is already saved locally, and new installs pick up the replacement on update.
_SHARED_TMDB_PARTS = (
    'ZXlKaGJHY2lPaUpJVXpJMU5pSjkuZXlKaGRXUWlPaUk1WkRFMFpqWmlZV001WkRBMU9EWTRZV00yTkdOaU1EUXhaVFF5WVRZNE5DSXNJbTVpWmlJNk1UYzFNVE13TURnMU9TNHlNakl3TURBeExDSnpkV0lpT2lJMk9E',
    'WXlZbUZtWWpkaVptSmhaVFU1TXpJNE5XTTNNVEVpTENKelkyOXdaWE1pT2xzaVlYQnBYM0psWVdRaVhTd2lkbVZ5YzJsdmJpSTZNWDAuX3VabnhFMGhfTW44TVM0QjlhYzhSQzNBazhwZW5zVnJjNGtidjBiR2R2RQ==',
)


def _get(url, headers=None):
    h = {'User-Agent': 'python-requests/2.28.2', 'Accept': '*/*'}
    h.update(headers or {})
    req = urllib.request.Request(url, headers=h)
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read())


def _post(url, data, headers=None):
    """POST as JSON (used by Trakt, Torbox)."""
    body = json.dumps(data).encode()
    h = {'Content-Type': 'application/json', 'User-Agent': 'python-requests/2.28.2', 'Accept': '*/*'}
    h.update(headers or {})
    req = urllib.request.Request(url, data=body, headers=h)
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read())


def _post_form(url, data, headers=None):
    """POST as form-encoded (required by RealDebrid token endpoint)."""
    body = urllib.parse.urlencode(data).encode()
    h = {'Content-Type': 'application/x-www-form-urlencoded'}
    h.update(headers or {})
    req = urllib.request.Request(url, data=body, headers=h)
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read())


class _AuthDialog(xbmcgui.WindowXMLDialog):
    """Full-screen auth dialog with QR code, countdown, and progress bar."""

    _BACK = (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_STOP)

    def __init__(self, *args, **kwargs):
        # Kodi's C++ WindowXMLDialog constructor expects the positional args as a tuple.
        # Calling super().__init__(xml, path, ...) separately causes Kodi to misread them.
        super().__init__(args)
        self.cancelled = False
        self._title = kwargs.get('title', '')
        self._url = kwargs.get('url', '')
        self._code = kwargs.get('code', '')
        self._qr_url = kwargs.get('qr_url', '')

    def onInit(self):
        try:
            self.getControl(101).setLabel(f'[B]{self._title}[/B]')
        except Exception:
            pass
        if self._qr_url:
            try:
                self.getControl(100).setImage(self._qr_url)
            except Exception:
                pass

    def update(self, text, progress):
        try:
            self.getControl(200).setText(text)
            self.getControl(300).setPercent(float(progress))
        except Exception:
            pass

    def iscanceled(self):
        return self.cancelled

    def onAction(self, action):
        if action.getId() in self._BACK:
            self.cancelled = True
            self.close()

    def run(self):
        self.doModal()


def _wait_for_auth(title, url, code, check_fn, interval, timeout):
    """
    Show auth dialog (QR + countdown) and poll check_fn every interval seconds.
    Updates dialog every second with remaining time. Returns result or False.
    """
    try:
        qr_url = _QR_URL % urllib.parse.quote(url, safe='')
    except Exception:
        qr_url = ''

    addon_path = xbmcvfs.translatePath('special://home/addons/script.welcome.setup/')
    window = _AuthDialog('auth_dialog.xml', addon_path, title=title, url=url, code=code, qr_url=qr_url)
    thread = Thread(target=window.run, daemon=True)
    thread.start()

    expires_at = time.monotonic() + timeout
    elapsed = 0
    result = None

    while not window.cancelled and time.monotonic() < expires_at:
        xbmc.sleep(1000)
        elapsed += 1
        remaining = max(0, expires_at - time.monotonic())
        mins, secs = divmod(int(remaining), 60)
        window.update(
            f'REMAINING: [B]{mins:02d}:{secs:02d}[/B][CR]'
            f'LOCATION: [B]{url}[/B][CR]'
            f'PIN CODE: [B]{code}[/B]',
            int(100 * remaining / timeout),
        )
        if elapsed % interval == 0:
            try:
                result = check_fn()
            except Exception as e:
                xbmc.log(f'{_LOG_TAG} Poll error ({title}): {e}', xbmc.LOGWARNING)
            if result is not None:
                break

    window.close()
    thread.join(timeout=2)
    xbmc.sleep(800)  # let the full-screen dialog fully dismiss before next UI appears
    return False if (window.cancelled or result is None) else result


def _write_pov_setting(key, value):
    """Write directly to POV's settings.xml, bypassing the addon registry."""
    addon_data = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.pov/')
    os.makedirs(addon_data, exist_ok=True)
    settings_path = os.path.join(addon_data, 'settings.xml')

    if os.path.exists(settings_path):
        try:
            tree = ET.parse(settings_path)
            root = tree.getroot()
        except ET.ParseError:
            root = ET.Element('settings', attrib={'version': '2'})
            tree = ET.ElementTree(root)
    else:
        root = ET.Element('settings', attrib={'version': '2'})
        tree = ET.ElementTree(root)

    setting = next((s for s in root.findall('setting') if s.get('id') == key), None)
    if setting is None:
        setting = ET.SubElement(root, 'setting', id=key)
    # POV ships every setting as <setting id=".." default="true" /> until the user
    # changes it. Kodi reads default="true" as "still the default (empty) value" and
    # ignores any text we put alongside it - so we must drop the attribute, exactly
    # as Kodi does when a user edits a setting, or getSetting() returns '' and POV
    # sees no token at all.
    if 'default' in setting.attrib:
        del setting.attrib['default']
    setting.text = str(value)
    tree.write(settings_path, encoding='unicode', xml_declaration=False)


def _read_pov_setting(key):
    """Read a value previously written by _write_pov_setting, or '' if unset/missing."""
    settings_path = os.path.join(
        xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.pov/'), 'settings.xml',
    )
    if not os.path.exists(settings_path):
        return ''
    try:
        root = ET.parse(settings_path).getroot()
        setting = next((s for s in root.findall('setting') if s.get('id') == key), None)
        return (setting.text or '') if setting is not None else ''
    except Exception:
        return ''


def is_authorized_realdebrid():
    return bool(_read_pov_setting('rd.token'))


def is_authorized_torbox():
    return bool(_read_pov_setting('tb.token'))


def is_authorized_trakt():
    return bool(_read_pov_setting('trakt.token'))


def is_authorized_tmdb():
    return bool(_read_pov_setting('tmdb_read_token'))


def _validate_realdebrid_token(token):
    try:
        _get('https://app.real-debrid.com/rest/1.0/user', headers={'Authorization': f'Bearer {token}'})
        return True
    except Exception as e:
        xbmc.log(f'{_LOG_TAG} Real-Debrid token validation failed: {e}', xbmc.LOGWARNING)
        return False


def _validate_torbox_token(token):
    try:
        resp = _get(f'{_TB_BASE}/user/me', headers={'Authorization': f'Bearer {token}'})
        return resp.get('success', True)
    except Exception as e:
        xbmc.log(f'{_LOG_TAG} Torbox token validation failed: {e}', xbmc.LOGWARNING)
        return False


def _validate_trakt_token(token):
    client_id = _read_pov_default('trakt.client_id')
    if not client_id:
        return True  # can't validate without our own client_id lookup; don't blame the user's token for that
    try:
        _get('https://api.trakt.tv/users/me', headers={
            'trakt-api-key': client_id,
            'trakt-api-version': '2',
            'Authorization': f'Bearer {token}',
        })
        return True
    except Exception as e:
        xbmc.log(f'{_LOG_TAG} Trakt token validation failed: {e}', xbmc.LOGWARNING)
        return False


def is_valid_realdebrid():
    """Unlike is_authorized_realdebrid(), actually pings Real-Debrid - a saved token
    can go stale (revoked, subscription lapsed) without us ever finding out otherwise,
    since presence-only checks would keep treating it as fine forever."""
    token = _read_pov_setting('rd.token')
    return bool(token) and _validate_realdebrid_token(token)


def is_valid_torbox():
    token = _read_pov_setting('tb.token')
    return bool(token) and _validate_torbox_token(token)


def is_valid_trakt():
    token = _read_pov_setting('trakt.token')
    return bool(token) and _validate_trakt_token(token)


def is_valid_tmdb():
    token = _read_pov_setting('tmdb_read_token')
    return bool(token) and _validate_tmdb_token(token)


_EXPECTED_POV_SETTING_IDS = (
    'rd.client_id', 'rd.secret', 'rd.token', 'rd.refresh', 'rd.username', 'rd.enabled',
    'tb.token', 'tb.account_id', 'tb.enabled',
    'trakt.token', 'trakt.refresh', 'trakt.expires', 'trakt_user',
    'trakt_indicators_active', 'watched_indicators',
    'tmdb_read_token',
)


def check_pov_settings_compat():
    """
    Cross-checks the setting IDs we write against POV's currently-installed
    resources/settings.xml schema. POV auto-updates via the repo; if a future
    version renames or drops one of these IDs, we'd otherwise keep writing values
    POV silently stops reading. Returns the subset of our expected IDs that POV no
    longer declares (empty if everything still matches, or if POV isn't installed
    yet / its settings.xml couldn't be parsed - nothing meaningful to flag then).
    """
    pov_dir = xbmcvfs.translatePath('special://home/addons/plugin.video.pov/')
    settings_path = os.path.join(pov_dir, 'resources', 'settings.xml')
    if not os.path.exists(settings_path):
        return []
    try:
        root = ET.parse(settings_path).getroot()
        declared_ids = {elem.get('id') for elem in root.iter('setting') if elem.get('id')}
    except Exception as e:
        xbmc.log(f'{_LOG_TAG} Failed to parse POV settings.xml for compat check: {e}', xbmc.LOGWARNING)
        return []
    return [sid for sid in _EXPECTED_POV_SETTING_IDS if sid not in declared_ids]


def _read_pov_default(key):
    """Read a default setting value from POV's bundled resources/settings.xml."""
    pov_dir = xbmcvfs.translatePath('special://home/addons/plugin.video.pov/')
    settings_path = os.path.join(pov_dir, 'resources', 'settings.xml')
    if not os.path.exists(settings_path):
        xbmc.log(f'{_LOG_TAG} POV resources/settings.xml not found', xbmc.LOGERROR)
        return ''
    try:
        tree = ET.parse(settings_path)
        root = tree.getroot()
        for elem in root.iter('setting'):
            if elem.get('id') == key:
                default_elem = elem.find('default')
                if default_elem is not None:
                    return default_elem.text or ''
                return elem.get('default', '')
    except Exception as e:
        xbmc.log(f'{_LOG_TAG} Failed to read POV default {key}: {e}', xbmc.LOGERROR)
    return ''


def _get_shared_tmdb_token():
    try:
        return base64.b64decode(''.join(_SHARED_TMDB_PARTS)).decode()
    except Exception:
        return ''


def _mark_tmdb_shared(is_shared):
    """Record whether the currently-saved TMDB token is the build's shared key."""
    try:
        if is_shared:
            with xbmcvfs.File(_TMDB_SHARED_FLAG, 'w') as f:
                f.write('1')
        elif xbmcvfs.exists(_TMDB_SHARED_FLAG):
            xbmcvfs.delete(_TMDB_SHARED_FLAG)
    except Exception as e:
        xbmc.log(f'{_LOG_TAG} Failed to update TMDB shared marker: {e}', xbmc.LOGWARNING)


def heal_tmdb_token_if_rotated():
    """
    Runs on the login path, but stays off the network for the normal case. If the
    saved token is a user's own pasted key (no marker) or already equals the current
    bundled shared key, this is a flag-stat + string compare and returns immediately.
    A network call happens only on the first login after a build update actually
    ships a *different* shared key - i.e. exactly when the old one was revoked and
    replaced - and only then swaps the dead token for the working new one. This is
    what makes "revoked key? just ship a new version" recover existing installs
    instead of leaving them stuck on a dead token.
    """
    if not xbmcvfs.exists(_TMDB_SHARED_FLAG):
        return  # custom key or TMDB not set up - never our place to touch it
    saved = _read_pov_setting('tmdb_read_token')
    bundled = _get_shared_tmdb_token()
    if not bundled or saved == bundled:
        return  # already on the current shared key - zero network
    # Saved shared key differs from what this build now bundles: a rotation shipped.
    if _validate_tmdb_token(bundled):
        _write_pov_setting('tmdb_read_token', bundled)
        xbmc.log(f'{_LOG_TAG} Healed TMDB token: swapped in rotated shared key', xbmc.LOGINFO)
    else:
        xbmc.log(f'{_LOG_TAG} TMDB rotation detected but new shared key did not validate', xbmc.LOGWARNING)


def _validate_tmdb_token(token):
    try:
        resp = _get(
            'https://api.themoviedb.org/3/authentication',
            headers={'Authorization': f'Bearer {token}'},
        )
        return bool(resp.get('success'))
    except Exception as e:
        xbmc.log(f'{_LOG_TAG} TMDB token validation error: {e}', xbmc.LOGWARNING)
        return False


def auth_tmdb():
    """
    POV's own list/metadata calls (tmdb_api.py) 401 without a TMDB key. Try the
    build's shared key first so this needs no user interaction at all; only fall
    back to manual entry if that shared key is missing or has been revoked.
    """
    dialog = xbmcgui.Dialog()

    shared_token = _get_shared_tmdb_token()
    if shared_token and _validate_tmdb_token(shared_token):
        _write_pov_setting('tmdb_read_token', shared_token)
        _mark_tmdb_shared(True)
        xbmc.log(f'{_LOG_TAG} TMDB authorized (built-in shared key)', xbmc.LOGINFO)
        return True

    xbmc.log(f'{_LOG_TAG} Built-in TMDB key unavailable, falling back to manual entry', xbmc.LOGWARNING)

    dialog.ok(
        'TMDB',
        'The built-in TMDB key is unavailable right now, so POV needs your own '
        'free TMDB API key to load movie/show info and build lists.\n\n'
        '1. Go to themoviedb.org and create a free account\n'
        '2. Settings -> API -> Create -> request an API key\n'
        '3. Copy the "API Read Access Token" (the long one)\n\n'
        'Tip: this token is long and painful to type with a remote. '
        'Easier options if typing here is hard (e.g. Android TV):\n'
        '- Install the "Kore" remote app on your phone, or use your '
        'TV\'s phone-keyboard casting\n'
        '- Or enable Settings -> Services -> Control -> Allow remote '
        'control via HTTP, then open http://<this-device-ip>:8080 in '
        'any browser and type there instead',
    )

    token = dialog.input('Paste your TMDB API Read Access Token')
    if not token:
        return False

    if not _validate_tmdb_token(token.strip()):
        dialog.ok('TMDB', 'That token was rejected by TMDB. Set it up later in POV settings.')
        return False

    _write_pov_setting('tmdb_read_token', token.strip())
    _mark_tmdb_shared(False)  # user's own key - self-heal must never overwrite it
    xbmc.log(f'{_LOG_TAG} TMDB authorized', xbmc.LOGINFO)
    dialog.notification('TMDB', 'API key saved!', xbmcgui.NOTIFICATION_INFO)
    return True


def auth_realdebrid():
    dialog = xbmcgui.Dialog()
    try:
        resp = _get(f'{_RD_BASE}/device/code?client_id={_RD_APP_CLIENT_ID}&new_credentials=yes')
    except Exception as e:
        xbmc.log(f'{_LOG_TAG} RD device code error: {e}', xbmc.LOGERROR)
        dialog.ok('Real-Debrid', 'Could not connect to Real-Debrid. Check your connection.')
        return False

    device_code = resp['device_code']
    user_code = resp['user_code']
    verification_url = resp.get('direct_verification_url') or resp['verification_url']
    poll_url = resp['verification_url']
    interval = resp.get('interval', 5)
    expires_in = resp.get('expires_in', 1800)

    credentials = {}

    def _check():
        try:
            data = _get(f'{_RD_BASE}/device/credentials?client_id={_RD_APP_CLIENT_ID}&code={device_code}')
            credentials.update(data)
            return credentials
        except Exception:
            return None

    if not _wait_for_auth('Real-Debrid', verification_url, user_code, _check, interval, expires_in):
        return False

    try:
        token_resp = _post_form(f'{_RD_BASE}/token', {
            'client_id': credentials['client_id'],
            'client_secret': credentials['client_secret'],
            'code': device_code,
            'grant_type': 'http://oauth.net/grant_type/device/1.0',
        })
        user_resp = _get(
            'https://app.real-debrid.com/rest/1.0/user',
            headers={'Authorization': f"Bearer {token_resp['access_token']}"},
        )
        _write_pov_setting('rd.client_id', credentials['client_id'])
        _write_pov_setting('rd.secret', credentials['client_secret'])
        _write_pov_setting('rd.token', token_resp['access_token'])
        _write_pov_setting('rd.refresh', token_resp['refresh_token'])
        _write_pov_setting('rd.username', user_resp.get('username', ''))
        _write_pov_setting('rd.enabled', 'true')
        xbmc.log(f'{_LOG_TAG} RealDebrid authorized', xbmc.LOGINFO)
        dialog.notification('Real-Debrid', 'Authorization successful!', xbmcgui.NOTIFICATION_INFO)
        return True
    except Exception as e:
        xbmc.log(f'{_LOG_TAG} RD token exchange error: {e}', xbmc.LOGERROR)
        dialog.ok('Real-Debrid', 'Authorization failed. Set it up later in POV settings.')
        return False


def auth_torbox():
    dialog = xbmcgui.Dialog()
    try:
        resp = _get(f'{_TB_BASE}/user/auth/device/start',
                     headers={'User-Agent': 'POV/1.0'})
        data = resp['data']
    except Exception as e:
        xbmc.log(f'{_LOG_TAG} Torbox device start error: {e}', xbmc.LOGERROR)
        dialog.ok('Torbox', 'Could not connect to Torbox. Check your connection.')
        return False

    device_code = data['device_code']
    user_code = data['code']
    verification_url = data.get('friendly_verification_url') or data.get('verification_url', 'torbox.app')
    interval = data.get('interval', 5)

    token_data = {}

    def _check():
        try:
            r = _post(f'{_TB_BASE}/user/auth/device/token', {'device_code': device_code})
            if r.get('data', {}).get('access_token'):
                token_data.update(r['data'])
                return token_data
            return None
        except Exception:
            return None

    if not _wait_for_auth('Torbox', verification_url, user_code, _check, interval, 600):
        return False

    try:
        access_token = token_data['access_token']
        user_resp = _get(f'{_TB_BASE}/user/me',
                          headers={'Authorization': f'Bearer {access_token}'})
        customer = user_resp.get('data', {}).get('customer', '')
        _write_pov_setting('tb.token', access_token)
        _write_pov_setting('tb.account_id', str(customer))
        _write_pov_setting('tb.enabled', 'true')
        xbmc.log(f'{_LOG_TAG} Torbox authorized', xbmc.LOGINFO)
        dialog.notification('Torbox', 'Authorization successful!', xbmcgui.NOTIFICATION_INFO)
        return True
    except Exception as e:
        xbmc.log(f'{_LOG_TAG} Torbox token error: {e}', xbmc.LOGERROR)
        dialog.ok('Torbox', 'Authorization failed. Set it up later in POV settings.')
        return False


def auth_trakt():
    dialog = xbmcgui.Dialog()
    client_id = _read_pov_default('trakt.client_id')
    client_secret = _read_pov_default('trakt.client_secret')

    if not client_id or not client_secret:
        xbmc.log(f'{_LOG_TAG} Trakt credentials not found in POV resources', xbmc.LOGERROR)
        dialog.ok('Trakt', 'Could not read Trakt credentials from POV.\nSet up Trakt later in POV settings.')
        return False

    _TRAKT_BASE = 'https://api.trakt.tv'

    try:
        resp = _post(f'{_TRAKT_BASE}/oauth/device/code',
                     {'client_id': client_id, 'client_secret': client_secret, 'code': ''})
    except Exception as e:
        xbmc.log(f'{_LOG_TAG} Trakt device code error: {e}', xbmc.LOGERROR)
        dialog.ok('Trakt', 'Could not connect to Trakt. Check your connection.')
        return False

    device_code = resp['device_code']
    user_code = resp['user_code']
    verification_url = resp['verification_url']
    interval = resp.get('interval', 5)
    expires_in = resp.get('expires_in', 600)

    token_resp = {}

    def _check():
        try:
            r = _post(f'{_TRAKT_BASE}/oauth/device/token',
                      {'client_id': client_id, 'client_secret': client_secret, 'code': device_code})
            if r.get('access_token'):
                token_resp.update(r)
                return token_resp
            return None
        except Exception:
            return None

    if not _wait_for_auth('Trakt', verification_url, user_code, _check, interval, expires_in):
        return False

    try:
        access_token = token_resp['access_token']
        _api_h = {'trakt-api-key': client_id, 'trakt-api-version': '2', 'Authorization': f'Bearer {access_token}'}
        user_resp = _get(f'{_TRAKT_BASE}/users/me', headers=_api_h)
        expires = int(token_resp['created_at']) + int(token_resp['expires_in'])
        _write_pov_setting('trakt.token', access_token)
        _write_pov_setting('trakt.refresh', token_resp['refresh_token'])
        _write_pov_setting('trakt.expires', str(expires))
        _write_pov_setting('trakt_user', user_resp.get('username', ''))
        _write_pov_setting('trakt_indicators_active', 'true')
        _write_pov_setting('watched_indicators', '1')
        xbmc.log(f'{_LOG_TAG} Trakt authorized', xbmc.LOGINFO)
        dialog.notification('Trakt', 'Authorization successful!', xbmcgui.NOTIFICATION_INFO)
        return True
    except Exception as e:
        xbmc.log(f'{_LOG_TAG} Trakt token error: {e}', xbmc.LOGERROR)
        dialog.ok('Trakt', 'Authorization failed. Set it up later in POV settings.')
        return False
