import os
import shutil

import xbmc
import xbmcvfs

_LOG_TAG = '[WelcomeSetup]'


def install_skin_config(addon_path):
    src_root = os.path.join(addon_path, 'resources', 'skin')
    dst_root = xbmcvfs.translatePath('special://userdata/addon_data/')
    count = 0

    for dirpath, _dirs, files in os.walk(src_root):
        for filename in files:
            src = os.path.join(dirpath, filename)
            rel = os.path.relpath(src, src_root)
            dst = os.path.join(dst_root, rel)
            # An addon's settings.xml belongs to that addon once it exists. On a
            # fresh profile it is absent, so we seed our bundled defaults (this is
            # the proven first-install path). On a re-run against an already-
            # configured profile, overwriting it would wipe the user's real
            # settings - most damagingly POV's own working TMDB token - so we
            # leave an existing one untouched. Skin shortcut/node files (not named
            # settings.xml) are always ours and keep refreshing.
            if filename == 'settings.xml' and os.path.exists(dst):
                xbmc.log(f'{_LOG_TAG} Preserved existing settings: {rel}', xbmc.LOGINFO)
                continue
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(src, dst)
            xbmc.log(f'{_LOG_TAG} Installed skin file: {rel}', xbmc.LOGINFO)
            count += 1

    xbmc.log(f'{_LOG_TAG} Skin config installed ({count} files)', xbmc.LOGINFO)
