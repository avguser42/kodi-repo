import sys

import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon('script.welcome.setup')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))

sys.path.insert(0, ADDON_PATH)

from lib.wizard import reset_wizard_state, run_diagnostics, run_wizard

if __name__ == '__main__':
    choice = xbmcgui.Dialog().select(
        'Welcome Setup',
        ['Run Setup Wizard', 'Run Diagnostics', 'Reset Setup State'],
    )
    if choice == 0:
        run_wizard(ADDON_PATH, manual=True)
    elif choice == 1:
        run_diagnostics(ADDON_PATH)
    elif choice == 2:
        reset_wizard_state()
