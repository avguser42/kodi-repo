import sys

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon('script.welcome.setup')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))

sys.path.insert(0, ADDON_PATH)

from lib import auth
from lib.wizard import run_wizard, top_up_if_config_changed

if __name__ == '__main__':
    xbmc.sleep(3000)  # wait for Kodi UI to be ready
    run_wizard(ADDON_PATH, manual=False)
    top_up_if_config_changed(ADDON_PATH)
    auth.heal_tmdb_token_if_rotated()  # zero network unless a rotated shared key shipped
