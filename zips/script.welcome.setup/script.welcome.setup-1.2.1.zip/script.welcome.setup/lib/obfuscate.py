"""
Light obfuscation for API keys that ship inside the addon (no Kodi imports so the
build helper in scripts/ can use it too). This only keeps keys out of casual
grep/bot scraping - the same idea as the TMDB shared key in auth.py - it is not
security: anyone running the addon can read them.
"""
import base64

_SALT = b'avguser42.welcome.setup'
_SPLITS = (7, 5)  # chunk sizes; the remainder is the last chunk


def _xor(data):
    return bytes(b ^ _SALT[i % len(_SALT)] for i, b in enumerate(data))


def encode(text):
    """text -> tuple of strings to paste into lib/keys.py."""
    blob = base64.urlsafe_b64encode(_xor(text.encode('utf-8'))).decode('ascii')[::-1]
    a, b = _SPLITS
    return (blob[:a], blob[a:a + b], blob[a + b:])


def decode(parts):
    """Inverse of encode(); '' for empty or corrupt input (a bad key must not crash a login)."""
    if not parts:
        return ''
    try:
        blob = ''.join(parts)[::-1]
        return _xor(base64.urlsafe_b64decode(blob)).decode('utf-8')
    except Exception:
        return ''
