from lib import obfuscate

# Shared free-tier API keys that make the skin's ratings work with no user setup.
# Fill with: python3 scripts/obfuscate_key.py <key>   (paste the printed tuple)
# Empty means "not shipped": the ratings step then does nothing.
_OMDB_PARTS = ('=cVQRZk', 'RRdRV', '')
_MDBLIST_PARTS = ('==gBVhB', 'AAFVG', 'WcBHcYVCREwSIRwRfcxERRRD')


def omdb_key():
    return obfuscate.decode(_OMDB_PARTS)


def mdblist_key():
    return obfuscate.decode(_MDBLIST_PARTS)
