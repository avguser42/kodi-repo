import os
import xml.etree.ElementTree as ET

import xbmc
import xbmcvfs

from lib import auth, keys

_LOG_TAG = '[WelcomeSetup]'

# (addon whose settings.xml holds the key, setting id, key supplier)
_TARGETS = (
    ('plugin.video.themoviedb.helper', 'omdb_apikey', keys.omdb_key),
    ('script.module.tmdbhelper.sync.mdblist', 'apikey', keys.mdblist_key),
)


def apply_shared_keys():
    """
    Give TMDb Helper the shared OMDb and MDbList keys so IMDb / Letterboxd /
    Rotten Tomatoes ratings show up in Arctic Fuse 3 without any user setup.
    Only fills an EMPTY setting, so a user's own key is never overwritten, and does
    nothing for a key that is not shipped or an addon that is not installed yet
    (it runs again on every login). No network. Returns how many keys were written.
    """
    addons_dir = xbmcvfs.translatePath('special://home/addons/')
    written = 0
    for addon_id, setting_id, supplier in _TARGETS:
        key = supplier()
        if not key or not os.path.exists(os.path.join(addons_dir, addon_id, 'addon.xml')):
            continue
        if auth.read_addon_setting(addon_id, setting_id):
            continue
        try:
            auth.write_addon_setting(addon_id, setting_id, key)
            written += 1
            xbmc.log(f'{_LOG_TAG} Ratings: set {setting_id} for {addon_id}', xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f'{_LOG_TAG} Ratings: failed to set {setting_id} for {addon_id}: {e}', xbmc.LOGWARNING)
    return written
