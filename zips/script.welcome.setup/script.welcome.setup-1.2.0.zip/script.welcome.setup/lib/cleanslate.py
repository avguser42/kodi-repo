import os
import shutil

import xbmc
import xbmcgui
import xbmcvfs

from lib import auth

_LOG_TAG = '[WelcomeSetup]'

# Never removed: the wizard itself and the repo that updates it. Everything else
# in the addons folder is reinstalled from scratch by the wizard.
_KEEP_ADDONS = {'script.welcome.setup', 'repository.avguser42'}

# Kodi decides which addons are enabled/new from the Addons DB. Wiping it would
# make Kodi treat our own (still on disk) wizard as a brand-new addon and leave
# it disabled, so the wizard would never start again. Stale rows for the addons
# we delete are harmless: the wizard enables what it installs.
_KEEP_DB_PREFIX = 'Addons'

# User-owned files that are not addon state.
_KEEP_USERDATA_FILES = {'guisettings.xml', 'advancedsettings.xml', 'sources.xml', 'favourites.xml', 'profiles.xml'}

# Only these userdata folders are touched; unknown folders are left alone.
_WIPE_USERDATA_DIRS = ('Thumbnails', 'keymaps', 'playlists', 'library', 'peripheral_data')

_SAFE_SKINS = ('skin.estuary', 'skin.confluence')


def _home():
    return os.path.realpath(xbmcvfs.translatePath('special://home/'))


def _inside(path, home):
    real = os.path.realpath(os.path.dirname(path)) if os.path.islink(path) else os.path.realpath(path)
    return real == home or real.startswith(home + os.sep)


def build_plan(home=None):
    """
    List of (absolute_path, label) to delete, computed without touching anything.
    Everything is under Kodi's home folder; Kodi's own bundled addons
    (special://xbmc/addons) are in a different place and are never involved.
    """
    home = home or _home()
    userdata = os.path.join(home, 'userdata')
    plan = []

    def add_children(folder, keep=()):
        if not os.path.isdir(folder):
            return
        for name in sorted(os.listdir(folder)):
            if name in keep:
                continue
            plan.append((os.path.join(folder, name), os.path.relpath(os.path.join(folder, name), home)))

    add_children(os.path.join(home, 'addons'), keep=_KEEP_ADDONS)
    add_children(os.path.join(userdata, 'addon_data'), keep={'script.welcome.setup'})

    db_dir = os.path.join(userdata, 'Database')
    if os.path.isdir(db_dir):
        for name in sorted(os.listdir(db_dir)):
            if not name.startswith(_KEEP_DB_PREFIX):
                plan.append((os.path.join(db_dir, name), os.path.relpath(os.path.join(db_dir, name), home)))

    for name in _WIPE_USERDATA_DIRS:
        path = os.path.join(userdata, name)
        if os.path.exists(path):
            plan.append((path, os.path.relpath(path, home)))

    # Loose files in userdata (wizard flag files, rss feeds, skin leftovers...)
    if os.path.isdir(userdata):
        for name in sorted(os.listdir(userdata)):
            path = os.path.join(userdata, name)
            if os.path.isfile(path) and name not in _KEEP_USERDATA_FILES:
                plan.append((path, os.path.relpath(path, home)))

    # Cached downloads/temp, but keep the logs for diagnosing what happened
    temp = os.path.join(home, 'temp')
    if os.path.isdir(temp):
        for name in sorted(os.listdir(temp)):
            if not name.endswith('.log') and not name.endswith('.old.log'):
                plan.append((os.path.join(temp, name), os.path.relpath(os.path.join(temp, name), home)))

    return plan


def execute_plan(plan, home=None):
    """Delete everything in the plan. Returns (removed, failed_labels)."""
    home = home or _home()
    removed, failed = 0, []
    for path, label in plan:
        try:
            if not _inside(path, home):
                raise RuntimeError('outside Kodi home, refusing')
            if os.path.islink(path) or os.path.isfile(path):
                os.unlink(path)
            elif os.path.isdir(path):
                shutil.rmtree(path)
            else:
                continue
            removed += 1
        except Exception as e:
            xbmc.log(f'{_LOG_TAG} Clean slate: failed to remove {label}: {e}', xbmc.LOGWARNING)
            failed.append(label)
    return removed, failed


def run_clean_slate(addon_path):
    dialog = xbmcgui.Dialog()

    skin = xbmc.getSkinDir()
    if skin not in _SAFE_SKINS:
        # Deleting the skin that is on screen breaks Kodi, and switching skins from
        # code has crashed it before, so the user does that part by hand.
        dialog.ok(
            'Clean Slate',
            f'The active skin ({skin}) would be deleted while it is in use.\n\n'
            'First switch to the default skin yourself:\n'
            'Settings -> Interface -> Skin -> Estuary\n\n'
            'Then run Clean Slate again.',
        )
        return

    plan = build_plan()
    if not plan:
        dialog.ok('Clean Slate', 'Nothing to remove - this Kodi is already clean.')
        return

    addon_count = sum(1 for p, _l in plan if os.path.dirname(p).endswith(os.sep + 'addons'))
    if dialog.yesno(
        'Clean Slate',
        f'This will remove {len(plan)} items, including {addon_count} addons, ALL addon settings, '
        'the video/music library and thumbnails.\n\nKept: this wizard, its repository, Kodi settings, sources, '
        'favourites and advanced settings.\n\nShow the full list first?',
        yeslabel='Show list',
        nolabel='Continue',
    ):
        dialog.textviewer('Clean Slate - will be removed', '\n'.join(label for _p, label in plan))

    if not dialog.yesno(
        'Clean Slate - are you sure?',
        'Kodi will close right after the cleanup. Start it again and the setup '
        'wizard will offer to install everything from scratch.\n\nThis cannot be undone.',
        yeslabel='Wipe now',
        nolabel='Cancel',
    ):
        return

    # Asked only now, after the final confirmation, so cancelling never leaves a
    # token backup lying around.
    auth.discard_accounts_backup()
    if dialog.yesno(
        'Clean Slate',
        'Keep your connected accounts (Real-Debrid, Torbox, Trakt, TMDB)?\n\n'
        'They are saved before the wipe and put back automatically during setup, '
        'so you will not have to log in again.',
        yeslabel='Keep logins',
        nolabel='Remove them',
    ):
        try:
            kept = auth.backup_accounts()
            xbmc.log(f'{_LOG_TAG} Clean slate: keeping {kept} account settings', xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f'{_LOG_TAG} Clean slate: account backup failed: {e}', xbmc.LOGERROR)
            dialog.ok('Clean Slate', 'Could not save your accounts, so nothing was removed. Nothing has changed.')
            return

    xbmc.log(f'{_LOG_TAG} Clean slate: removing {len(plan)} items', xbmc.LOGINFO)
    removed, failed = execute_plan(plan)
    xbmc.log(f'{_LOG_TAG} Clean slate: removed {removed}, failed {len(failed)}', xbmc.LOGINFO)

    if failed:
        shown = ', '.join(failed[:5]) + (', ...' if len(failed) > 5 else '')
        dialog.ok(
            'Clean Slate',
            f'Removed {removed} items, but {len(failed)} could not be removed (in use?):\n{shown}\n\n'
            'Kodi will close now. Run Clean Slate again after restarting to finish.',
        )
    else:
        dialog.ok('Clean Slate', f'Removed {removed} items. Kodi will now close - start it again to set up.')

    # Kodi rewrites settings/DBs on a normal exit, which would bring back state we
    # just deleted, so end the process directly (same approach as GRecoTM's wizard).
    os._exit(0)
