import re

import xbmc
import xbmcaddon

_LOG_TAG = '[WelcomeSetup]'


def version_key(v):
    """Loose, order-preserving key for addon/Kodi version strings ('3.4.22', '1.0.0~beta')."""
    return tuple(int(x) for x in re.findall(r'\d+', v or ''))


def kodi_version():
    """
    (major, minor, patch) of the running Kodi. BuildVersion looks like
    '21.3 (21.3.0) Git:...'; pre-releases of a new major report 21.9x internally
    (Piers RCs are 21.90.x), so the parenthesised number is preferred.
    """
    label = xbmc.getInfoLabel('System.BuildVersion') or ''
    m = re.search(r'\((\d+\.\d+(?:\.\d+)?)\)', label) or re.match(r'\s*(\d+\.\d+(?:\.\d+)?)', label)
    if not m:
        xbmc.log(f'{_LOG_TAG} Could not parse Kodi version from {label!r}, assuming 21.0.0', xbmc.LOGWARNING)
        return (21, 0, 0)
    parts = [int(x) for x in m.group(1).split('.')]
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts[:3])


def release_name(version=None):
    """Name used in Kodi's official mirror paths and in our pins.json."""
    major, minor, _patch = version or kodi_version()
    if major >= 22 or (major == 21 and minor >= 90):
        return 'piers'
    if major == 21:
        return 'omega'
    if major == 20:
        return 'nexus'
    return 'matrix'


def gui_version():
    """Version of the xbmc.gui API this Kodi provides (e.g. 5.17.0 on Omega)."""
    try:
        return xbmcaddon.Addon('xbmc.gui').getAddonInfo('version')
    except Exception:
        return ''


def requirements_met(requires, gui=None):
    """
    requires: {import_id: min_version} from an addon.xml <requires>.
    Only xbmc.gui is enforced - it is the one that pins a skin to a Kodi release
    and the one Kodi itself refuses on ('not compatible with this version').
    Unknown gui version (lookup failed) is treated as compatible.
    """
    have = gui if gui is not None else gui_version()
    need = requires.get('xbmc.gui')
    if not need or not have:
        return True
    return version_key(need) <= version_key(have)
