import gzip
import json
import os
import re
import shutil
import time
import urllib.request
import xml.etree.ElementTree as ET
import zipfile

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from lib import kodi_env

_LOG_TAG = '[WelcomeSetup]'
_RETRY_ATTEMPTS = 3
_RETRY_DELAY = 2  # seconds


def _ver_tuple(v):
    try:
        return tuple(int(x) for x in v.split('.'))
    except Exception:
        return (0,)


def _retry(fn, label=''):
    """First-boot Wi-Fi on a fresh TV box is often flaky; retry transient network
    failures a couple of times before giving up on that item."""
    last_exc = None
    for attempt in range(1, _RETRY_ATTEMPTS + 1):
        try:
            return fn()
        except Exception as e:
            last_exc = e
            if attempt < _RETRY_ATTEMPTS:
                xbmc.log(f'{_LOG_TAG} {label} attempt {attempt}/{_RETRY_ATTEMPTS} failed: {e}, retrying...', xbmc.LOGWARNING)
                xbmc.sleep(_RETRY_DELAY * 1000)
    raise last_exc


class Installer:
    def __init__(self, addon_path, skip_existing=True):
        self.resources = os.path.join(addon_path, 'resources')
        self.addons_dir = xbmcvfs.translatePath('special://home/addons/')
        self.progress = xbmcgui.DialogProgress()
        self.skip_existing = skip_existing
        self.pins = self._load_pins()
        self.stats = {'repos_installed': 0, 'addons_installed': 0, 'settings_applied': 0, 'failed': []}

    def run(self):
        repos = self._load('repos.json')
        addons = self._load('addons.json')
        settings = self._load('settings.json')

        xbmc.log(f'{_LOG_TAG} run: {len(repos)} repos, {len(addons)} addons, {len(settings)} settings', xbmc.LOGINFO)

        if not repos and not addons and not settings:
            xbmcgui.Dialog().ok('Setup', 'No items configured yet.')
            return self.stats

        total = len(repos) + len(addons) + len(settings)
        self.progress.create('Welcome Setup', 'Starting...')
        step = 0

        # Step 1: extract repo zips
        for repo in repos:
            if self.progress.iscanceled():
                self.progress.close()
                return self.stats
            if repo.get('index_only'):
                step += 1
                continue
            self.progress.update(self._pct(step, total), f"Installing repo: {repo.get('name', repo.get('id', ''))}")
            self._install_repo(repo)
            step += 1

        # Step 2: build download index from each repo's addons.xml
        self.progress.update(self._pct(step, total), 'Indexing repositories...')
        addon_index = self._build_addon_index(repos)

        # Step 3: download each addon directly (no Kodi installer needed)
        for addon_id in addons:
            if self.progress.iscanceled():
                self.progress.close()
                return self.stats
            self.progress.update(self._pct(step, total), f'Installing: {addon_id}')
            self._install_addon(addon_id, addon_index)
            step += 1

        # Step 4: apply settings
        for entry in settings:
            if self.progress.iscanceled():
                self.progress.close()
                return self.stats
            self.progress.update(self._pct(step, total), f"Applying setting: {entry.get('key', '')}")
            self._apply_setting(entry)
            step += 1

        self.progress.close()
        return self.stats

    # --- helpers ---

    def _load(self, filename):
        path = os.path.join(self.resources, filename)
        if not xbmcvfs.exists(path):
            return []
        with xbmcvfs.File(path) as f:
            try:
                return json.loads(f.read())
            except Exception as e:
                xbmc.log(f'{_LOG_TAG} Failed to parse {filename}: {e}', xbmc.LOGERROR)
                return []

    def _load_pins(self):
        path = os.path.join(self.resources, 'pins.json')
        try:
            with open(path, encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            return {}
        except Exception as e:
            xbmc.log(f'{_LOG_TAG} Failed to parse pins.json: {e}', xbmc.LOGERROR)
            return {}

    def _installed_incompatible(self, addon_id):
        """True if the installed copy declares an xbmc.gui newer than this Kodi
        provides - Kodi refuses to load it ('not compatible with this version')."""
        try:
            root = ET.parse(os.path.join(self.addons_dir, addon_id, 'addon.xml')).getroot()
        except Exception:
            return False
        requires = {i.get('addon', ''): i.get('version', '') for i in root.findall('./requires/import')}
        return not kodi_env.requirements_met(requires)

    @staticmethod
    def _pct(step, total):
        return int(step / total * 100) if total else 0

    def _install_repo(self, repo):
        addon_id = repo.get('id', 'unknown')
        source_url = repo.get('source_url', '').rstrip('/')
        if not source_url:
            return
        if self.skip_existing and os.path.exists(os.path.join(self.addons_dir, addon_id, 'addon.xml')):
            xbmc.log(f'{_LOG_TAG} Already installed: {addon_id}', xbmc.LOGINFO)
            return
        try:
            def _fetch_listing():
                with urllib.request.urlopen(source_url + '/', timeout=10) as resp:
                    return resp.read().decode('utf-8', errors='replace')
            content = _retry(_fetch_listing, label=f'{addon_id} listing')

            match = re.search(rf'{re.escape(addon_id)}-[\d.]+\.zip', content)
            if not match:
                xbmc.log(f'{_LOG_TAG} {addon_id} zip not found at {source_url}', xbmc.LOGERROR)
                self.stats['failed'].append(addon_id)
                return
            zip_url = f'{source_url}/{match.group(0)}'
            tmp = xbmcvfs.translatePath(f'special://temp/{addon_id}.zip')
            _retry(lambda: urllib.request.urlretrieve(zip_url, tmp), label=f'{addon_id} download')
            with zipfile.ZipFile(tmp, 'r') as zf:
                zf.extractall(self.addons_dir)
            xbmcvfs.delete(tmp)
            xbmc.log(f'{_LOG_TAG} Installed repo: {addon_id}', xbmc.LOGINFO)
            self.stats['repos_installed'] += 1
        except Exception as e:
            xbmc.log(f'{_LOG_TAG} Failed repo {addon_id}: {e}', xbmc.LOGERROR)
            self.stats['failed'].append(addon_id)

    def _build_addon_index(self, repos):
        """
        Download addons.xml from each repo and build {addon_id: zip_url}. A repo
        can list the same addon in several version dirs and several repos can
        overlap, so every listing is a candidate and the highest version whose
        xbmc.gui requirement this Kodi satisfies wins. (Taking the first listing
        installed a Kodi 22-only Arctic Fuse 3 on Kodi 21.3.)
        """
        kodi = kodi_env.kodi_version()
        gui = kodi_env.gui_version()
        release = kodi_env.release_name(kodi)
        candidates = {}  # addon_id -> [(version_key, version, url, compatible)]
        xbmc.log(f'{_LOG_TAG} Kodi {".".join(map(str, kodi))} ({release}), xbmc.gui {gui or "unknown"}', xbmc.LOGINFO)

        def _collect(addons_root, datadir, repo_id):
            count = 0
            for addon_elem in addons_root.findall('addon'):
                aid = addon_elem.get('id', '')
                ver = addon_elem.get('version', '')
                if not aid or not ver:
                    continue
                requires = {
                    imp.get('addon', ''): imp.get('version', '')
                    for imp in addon_elem.findall('./requires/import')
                }
                ok = kodi_env.requirements_met(requires, gui)
                candidates.setdefault(aid, []).append(
                    (kodi_env.version_key(ver), ver, f'{datadir}/{aid}/{aid}-{ver}.zip', ok)
                )
                count += 1
            xbmc.log(f'{_LOG_TAG} Indexed {count} addons from {repo_id}', xbmc.LOGINFO)

        for repo in repos:
            repo_id = repo.get('id', '')

            if repo.get('index_only'):
                addons_xml_url = repo.get('addons_xml_url', '').replace('{release}', release)
                datadir = repo.get('datadir', '').replace('{release}', release).rstrip('/')
                if not addons_xml_url or not datadir:
                    continue
                try:
                    _collect(ET.fromstring(self._fetch_addons_xml(addons_xml_url)), datadir, repo_id)
                except Exception as e:
                    xbmc.log(f'{_LOG_TAG} Failed to index {repo_id}: {e}', xbmc.LOGWARNING)
                continue

            addon_xml_path = os.path.join(self.addons_dir, repo_id, 'addon.xml')
            if not os.path.exists(addon_xml_path):
                xbmc.log(f'{_LOG_TAG} {repo_id}/addon.xml not found', xbmc.LOGWARNING)
                continue
            try:
                root = ET.parse(addon_xml_path).getroot()
                repo_ext = root.find('.//extension[@point="xbmc.addon.repository"]')
                if repo_ext is None:
                    continue
                for dir_elem in repo_ext.findall('dir'):
                    min_v = _ver_tuple(dir_elem.get('minversion', '0'))
                    max_v = _ver_tuple(dir_elem.get('maxversion', '999'))
                    if not (min_v <= kodi <= max_v):
                        continue
                    info_elem = dir_elem.find('info')
                    datadir_elem = dir_elem.find('datadir')
                    if info_elem is None or datadir_elem is None:
                        continue
                    info_url = info_elem.text.strip()
                    datadir = datadir_elem.text.strip().rstrip('/')
                    try:
                        def _fetch():
                            with urllib.request.urlopen(info_url, timeout=15) as resp:
                                return resp.read()
                        addons_xml = _retry(_fetch, label=f'{repo_id} addons.xml')
                        _collect(ET.fromstring(addons_xml), datadir, repo_id)
                    except Exception as e:
                        xbmc.log(f'{_LOG_TAG} Failed to fetch addons.xml from {repo_id}: {e}', xbmc.LOGWARNING)
            except Exception as e:
                xbmc.log(f'{_LOG_TAG} Failed to parse {repo_id}/addon.xml: {e}', xbmc.LOGERROR)

        index = {}
        for aid, options in candidates.items():
            compatible = [o for o in options if o[3]]
            if compatible:
                index[aid] = max(compatible)[2]
            else:
                newest = max(options)
                xbmc.log(
                    f'{_LOG_TAG} {aid}: newest listed version {newest[1]} needs a newer Kodi '
                    f'than {".".join(map(str, kodi))}, no compatible version in the index',
                    xbmc.LOGWARNING,
                )

        # Pins fill in what the repos cannot: a repo that only lists a too-new
        # version (Arctic Fuse 3 on Omega) still has older zips on its server.
        for aid, by_release in self.pins.items():
            if aid not in index and by_release.get(release):
                index[aid] = by_release[release]
                xbmc.log(f'{_LOG_TAG} {aid}: using pinned {release} build {index[aid]}', xbmc.LOGINFO)

        xbmc.log(f'{_LOG_TAG} Total index: {len(index)} addons', xbmc.LOGINFO)
        return index

    def _fetch_addons_xml(self, addons_xml_url):
        """
        The official Kodi repo's addons.xml is ~12MB uncompressed but ~2MB gzipped
        (mirrors.kodi.tv serves both). Try the .gz first since it's much faster on
        a slow connection; fall back to the plain XML with a longer timeout.
        """
        try:
            def _fetch_gz():
                with urllib.request.urlopen(addons_xml_url + '.gz', timeout=20) as resp:
                    return gzip.decompress(resp.read())
            return _retry(_fetch_gz, label='addons.xml.gz')
        except Exception as e:
            xbmc.log(f'{_LOG_TAG} Falling back to uncompressed addons.xml: {e}', xbmc.LOGWARNING)

        def _fetch_plain():
            with urllib.request.urlopen(addons_xml_url, timeout=90) as resp:
                return resp.read()
        return _retry(_fetch_plain, label='addons.xml')

    def _install_addon(self, addon_id, addon_index):
        addon_path = os.path.join(self.addons_dir, addon_id, 'addon.xml')
        replace_incompatible = os.path.exists(addon_path) and self._installed_incompatible(addon_id)
        if self.skip_existing and os.path.exists(addon_path) and not replace_incompatible:
            xbmc.log(f'{_LOG_TAG} Already installed: {addon_id}', xbmc.LOGINFO)
            return
        zip_url = addon_index.get(addon_id)
        if not zip_url:
            xbmc.log(f'{_LOG_TAG} Not in any repo index: {addon_id}', xbmc.LOGERROR)
            self.stats['failed'].append(addon_id)
            return
        xbmc.log(f'{_LOG_TAG} Downloading {addon_id} from {zip_url}', xbmc.LOGINFO)
        try:
            tmp = xbmcvfs.translatePath(f'special://temp/{addon_id}.zip')
            _retry(lambda: urllib.request.urlretrieve(zip_url, tmp), label=f'{addon_id} download')
            with zipfile.ZipFile(tmp, 'r') as zf:
                if replace_incompatible:
                    # extractall alone would leave the newer version's files mixed in
                    xbmc.log(f'{_LOG_TAG} Replacing installed {addon_id}: not compatible with this Kodi', xbmc.LOGWARNING)
                    shutil.rmtree(os.path.join(self.addons_dir, addon_id), ignore_errors=True)
                zf.extractall(self.addons_dir)
            xbmcvfs.delete(tmp)
            xbmc.log(f'{_LOG_TAG} Installed: {addon_id}', xbmc.LOGINFO)
            self.stats['addons_installed'] += 1
        except Exception as e:
            xbmc.log(f'{_LOG_TAG} Failed to install {addon_id}: {e}', xbmc.LOGERROR)
            self.stats['failed'].append(addon_id)

    def _apply_setting(self, entry):
        try:
            addon_id = entry.get('addon_id')
            key = entry.get('key', '')
            value = str(entry.get('value', ''))
            if addon_id:
                xbmcaddon.Addon(addon_id).setSetting(key, value)
            else:
                xbmc.executeJSONRPC(json.dumps({
                    'jsonrpc': '2.0',
                    'method': 'Settings.SetSettingValue',
                    'params': {'setting': key, 'value': entry.get('value')},
                    'id': 1,
                }))
            xbmc.log(f'{_LOG_TAG} Applied setting {key}={value}', xbmc.LOGINFO)
            self.stats['settings_applied'] += 1
        except Exception as e:
            xbmc.log(f'{_LOG_TAG} Failed setting {entry}: {e}', xbmc.LOGERROR)
            self.stats['failed'].append(entry.get('key', 'unknown-setting'))
